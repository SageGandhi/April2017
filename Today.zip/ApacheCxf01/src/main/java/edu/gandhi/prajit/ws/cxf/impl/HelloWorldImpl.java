package edu.gandhi.prajit.ws.cxf.impl;

import javax.jws.WebService;

import edu.gandhi.prajit.ws.cxf.HelloWorld;
@WebService(endpointInterface="edu.gandhi.prajit.ws.cxf.HelloWorld",serviceName="HelloWorld")
public class HelloWorldImpl implements HelloWorld {
	@Override
	public String sayHi(String text) {
		System.out.println("Method Invoked");
		return "Welcome !!!"+text;
	}
}
