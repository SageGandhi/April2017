package edu.gandhi.prajit.ws.jaxb.xjc01;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.prajit.gandhi.edu.schema.userprofile.ObjectFactory;
import org.prajit.gandhi.edu.schema.userprofile.UserProfile;

public class JaxbMarshallUnMarshall {

	public static void main(String[] args) throws Exception {
		final JAXBContext context =JAXBContext.newInstance(UserProfile.class);
		
		final Marshaller marshaller = context.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,Boolean.TRUE);
		
		final Unmarshaller unmarshaller = context.createUnmarshaller();
		
		final ObjectFactory userFactory = new ObjectFactory();
		
		final UserProfile userProfile = userFactory.createUserProfile();
		userProfile.setAddress(userFactory.createAddress());
		
		userProfile.setUserName("Prajit Gandhi");
		userProfile.setEmail("prajit.ju@gmail.com");
		userProfile.getAddress().setCity("Kolkata");
		userProfile.getAddress().setCountry("India");
		userProfile.getAddress().setState("WestBengal");
		userProfile.getAddress().setStreetAddress("Na");
		userProfile.getAddress().setZipcode("700000");
		
		final StringWriter writer = new StringWriter();
		
		marshaller.marshal(userProfile, writer);
		
		System.out.println(writer.toString());
		
		final UserProfile userProfileUnmarshaller = (UserProfile) unmarshaller.unmarshal(new StringReader(writer.toString()));
		System.out.println(userProfileUnmarshaller.getUserName());
		System.out.println(userProfileUnmarshaller.getEmail());
		System.out.println(userProfileUnmarshaller.getAddress().getCity());
		System.out.println(userProfileUnmarshaller.getAddress().getCountry());
		System.out.println(userProfileUnmarshaller.getAddress().getState());
		System.out.println(userProfileUnmarshaller.getAddress().getStreetAddress());
		System.out.println(userProfileUnmarshaller.getAddress().getZipcode());
	}
}
